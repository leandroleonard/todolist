<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>TUDO LIST - PHP + JavaScript & Ajax</title>
	<link rel="stylesheet" type="text/css" href="<?=URL?>public/css/app.css">
	<link rel="stylesheet" type="text/css" href="<?=URL?>public/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?=URL?>public/css/icons.css">
</head>
<body>
	<nav class="navbar navbar-expand navbar-dark bg-danger">
		<strong>
			<a href="#" class="navbar-brand">TUDO LIST</a>
		</strong>
	</nav>

	<div class="container my-5">
		<div class="row">
			<div class="col-md-6">
				<h2>TASKS</h2>
			</div>
			<div class="col-md-6 text-right">
				<button class="btn btn-danger" id="add">New task</button>
			</div>
		</div>
				
		<div class="row">
			<div class="col-md-12">
				<div id="div_alert" style="display:none;" class="text-center alert alert-info">
					<span id="alert_message"></span>
				</div>
				
				<table class="table table-hover">
					<thead>
						<tr>
							<th>Task</th>
							<th>Created at</th>
							<th>Complete at</th>
							<th>Opções</th>
						</tr>
					</thead>
					<tbody id="data">
						
					</tbody>
				</table>
			</div>
		</div>
	</div>


	<?php include "templates/modal.html"?>
	<script src="<?=URL?>public/js/app.js"></script>
	<script src="<?=URL?>public/js/vendor.js"></script>
	<script src="<?=URL?>public/js/index.js"></script>

	<script>
		$(document).ready(function(){
			$("button[id='delete']").click(function(){
				// var id = $(this).data('id');
				// getDetails(id);
				// $('#modal_delete').modal('show');
				alert("ola");
			});
		});
	</script>

</body>
</html>