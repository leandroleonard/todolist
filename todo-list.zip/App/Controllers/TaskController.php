<?php
	namespace App\Controllers;
	use Core\Models\TaskModel;

	class TaskController
	{
		public function index(){
			$task = new TaskModel;
			return $task->show_tasks();
		}

		public function add($task){
		    $task_obj = new TaskModel;
		    try{
		        
				if ($task_obj->insert($task)) {
					$output["message"] 	= "Success";
					return $output;
				}else{
					$output["error"] 	= true;
					$output["message"] 	= "Somethink went wrong. Cannot add task";
					return $output;
				}
			}catch(\PDOException $e){
				$output["error"] 		= true;
				$output["message"] 	= $e->getMessage();

				return $output;
			}
		}

		public function remove($id){
			$task_obj = new TaskModel;
		    try{
		        
				if ($task_obj->delete($id)) {
					$output["message"] 	= "Task deleted successfully!";
					return $output;
				}else{
					$output["error"] 	= true;
					$output["message"] 	= "Somethink went wrong. Cannot delete task";
					return $output;
				}
			}catch(\PDOException $e){
				$output["error"] 		= true;
				$output["message"] 	= $e->getMessage();

				return $output;
			}
		}
	}