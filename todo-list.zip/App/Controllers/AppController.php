<?php 
	namespace App\Controllers;

	class AppController
	{
		public function index(){
			require_once APP . "views/index.php";
		}

		public function inde(){
			echo "ola mundo";
		}
	}