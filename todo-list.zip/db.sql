create table tasks(
	id int primary key auto_increment,
	task varchar(225) not null,
	created_at datetime not null,
	updated_at datetime
)