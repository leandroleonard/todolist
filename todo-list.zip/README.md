# TODO LIST
- Tecnologias: PHP, JavaScript(JQuery, Ajax), MySQL;

## Testado em
- Windows 10 com PHP 7.3

## Estrutura de arquivos
- composer.json
- db.sql
- .htaccess
- public
    - .htaccess
    - ajax
    - css
    - img
    - js
    - index.php
- App
    - Controllers
        - AppController
        - TaskController
    - views
        - templates
            - 404.php
            - modal.html
        - index.php
- Core
	- .htaccess
	- models
		- TaskModel
    - config.php
    - Database.php
    - ErrorController.php
    - Router.php
