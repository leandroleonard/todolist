$(document).ready(function(){
	$("#add").on("click", function(){
		$("#modal_new_task").modal("show");
	});

	show_data();

	$('#form_task').submit(function(e){
		e.preventDefault();
		var task = $(this).serialize();
		
		$.ajax({
			method: 'POST',
			url: 'ajax/save.php',
			data: task,
			dataType: 'json',
			success: function(response){
				if(response.error){
					$('#modal_new_task').modal('hide');
					$('#div_alert').addClass("alert-danger");
					$('#div_alert').show();
					$('#alert_message').html(response.message);

					window.setInterval(function(){
						$("#div_alert").fadeOut();
					}, 3500) ;
				}
				else{
					$('#modal_new_task').modal('hide');
					$('#div_alert').addClass("alert-success");
					$('#div_alert').show();
					$('#alert_message').html(response.message);
					$('#task').val("");
					show_data();
					window.setInterval(function(){
						$("#div_alert").fadeOut();
					}, 3500) ;
				}
			}
		});
	});
	
	function show_data(){
		$.ajax({
			method: "post",
			url: "ajax/data.php",
			success: function(dataResult){
				$("#data").html(dataResult);
			}
		});
	}

	$(document).on('click', '#delete', function(){
		var id = $(this).data('id');
		$.ajax({
			method: 'POST', 
			url: 'ajax/delete.php',
			data: {id:id},
			success: function(response){
				if(response.error){
					$('#div_alert').addClass("alert-danger");
					$('#div_alert').show();
					$('#alert_message').html(response.message);
					console.log("nao chegou");
					window.setInterval(function(){
						$("#div_alert").fadeOut();
					}, 3500) ;
				}
				else{
					$('#div_alert').addClass("alert-success");
					$('#div_alert').show();
					$('#alert_message').html("Task deleted successfully!");
					show_data();
					window.setInterval(function(){
						$("#div_alert").fadeOut();
					}, 3500) ;
				}				
			}
		});
	});
});