<?php 
	
	require "router.php";

	use App\Controllers\TaskController;

	$obj 	= new TaskController();

	$tasks 	= $obj->index();
?>
<?php if($tasks->rowCount() > 0): ?>
	<?php foreach($tasks as $task): ?>
		<tr>
			<td><?=$task["id"]?></td>
			<td><?=$task["task"]?></td>
			<td><?=$task["created_at"]?></td>
			<td>
				<button class="btn btn-info mr-2" data-id="<?=$task['id']?>">
					Editar
				</button>

				<button data-id="<?=$task['id']?>" class="btn btn-danger " id="delete">
					Apagar
				</button>
			</td>
		</tr>
	<?php endforeach ?>
<?php else: ?>
	<tr>
		<td></td>
		<td>No data avaliabou</td>
		<td></td>
	</tr>
<?php endif ?>


