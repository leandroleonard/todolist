<?php
	require_once "router.php";
	use App\Controllers\TaskController;
	
	if (isset($_POST["task"]) && !empty($_POST["task"])) {

		$output = ["error" => false];	

		$task = new TaskController;
		$task->add($_POST['task']);

		$output["message"] 	= "Success";
		echo json_encode($output);
	}else{
		$output["error"] 	= true;
		$output["message"] 	= "Data is required.";
		echo json_encode($output);
	}