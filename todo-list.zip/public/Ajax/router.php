<?php
	define('ROOT', dirname(__DIR__) . DIRECTORY_SEPARATOR);
	define('CORE', ROOT . '../Core' . DIRECTORY_SEPARATOR);

	require ROOT . '../vendor/autoload.php';

	require CORE . 'config.php';