<?php
	namespace Core\Models;
	use Core\Database;

	class TaskModel extends Database
	{
		private $table = "tasks";
		public function show_tasks(){
			return $this->open()->query("SELECT * from $this->table");
		}

		public function insert($task){
			$created_at = date("Y-m-d H:i:s");
	        $stmt = $this->open()->prepare("INSERT INTO tasks (task, created_at) VALUES (:task, :created_at)");
	        $stmt->execute(
	        	[':task' => $task, ':created_at' => $created_at]
	        ); 
	    }

	    public function delete($id){
			$sql = "DELETE FROM tasks WHERE id = '$id'";
			$this->open()->exec($sql);
	    }
	}