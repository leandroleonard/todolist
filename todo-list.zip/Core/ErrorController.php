<?php

    namespace Core;

    class ErrorController
    {
        public function index()
        {
            require APP . 'views/templates/404.php';
        }
    }
