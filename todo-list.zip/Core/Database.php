<?php
    namespace Core;

    class Database
    {
        public  $pdo;
        private $host;
        private $user;
        private $pass;
        private $db;

        public function open()
        {
            $this->host = HOST;
            $this->user = USER;
            $this->pass = PASS;
            $this->db   = DB;
            $dsn = 'mysql:host='.$this->host.';dbname='.$this->db;

            try {
                $options = array(\PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC, \PDO::ATTR_ERRMODE => \PDO::ERRMODE_WARNING);
                $pdo = new \PDO($dsn, $this->user, $this->pass, $options );

                return $pdo;

            } catch (\PDOException $e) {
                print "Error!: " . $e->getMessage() . "<br/>";
                die();
            }
        }
    }
